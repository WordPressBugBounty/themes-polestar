<h3><?php esc_html_e( 'Easy Setup and Customization', 'polestar' ) ?></h3>
<p>
	<?php printf( esc_html__( "Polestar is easy to setup and customize, get started in the %sWordPress Customizer%s.", 'polestar' ), '<a href="' . admin_url( 'customize.php' ) . '">', '</a>' ) ?>
</p>
